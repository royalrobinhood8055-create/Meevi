export interface Song {
    title: string;
    artist: string;
    cover: string;
    album?: string;
    ytId: string | null;
    searchQuery: string;
}

export interface Playlist {
    name: string;
    songs: Song[];
}

export interface UserProfile {
    name: string;
    handle: string;
}

export interface Artist {
    name: string;
    img: string;
}

export type ViewType = 'home' | 'search' | 'library';

export interface AppState {
    songs: Song[];
    currentSongIndex: number;
    isPlaying: boolean;
    isShuffle: boolean;
    isRepeat: boolean;
    history: Song[];
    likedSongs: Song[];
    playlists: Playlist[];
    userProfile: UserProfile;
    savedArtists: Artist[];
    isBuffering: boolean;
    currentTime: number;
    duration: number;
    view: ViewType;
    showFullPlayer: boolean;
    showSettings: boolean;
    showCreatePlaylist: boolean;
    showAddToPlaylist: boolean;
    showAddArtist: boolean;
    showVolume: boolean;
    showHistory: boolean;
    showProfileEdit: boolean;
    showQueue: boolean;
    genericPage: {
        isOpen: boolean;
        title: string;
        songs: Song[];
    }
}