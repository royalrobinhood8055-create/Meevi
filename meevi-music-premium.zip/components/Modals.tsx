import React, { useState } from 'react';
import { Song, Playlist, UserProfile, Artist } from '../types';

const useSwipeDown = (onClose: () => void, threshold = 100) => {
    const [touchStart, setTouchStart] = useState<number | null>(null);
    const [touchMove, setTouchMove] = useState<number | null>(null);

    const onTouchStart = (e: React.TouchEvent) => {
        // Only allow swipe to close if starting from the top header area (e.g., top 150px)
        // This prevents accidental closes when scrolling up a list in the middle of the screen
        if (e.targetTouches[0].clientY > 150) return;
        setTouchStart(e.targetTouches[0].clientY);
    };

    const onTouchMove = (e: React.TouchEvent) => {
        if (touchStart === null) return;
        setTouchMove(e.targetTouches[0].clientY);
    };

    const onTouchEnd = () => {
        if (!touchStart || !touchMove) return;
        const distance = touchMove - touchStart;
        if (distance > threshold) {
            onClose();
        }
        setTouchStart(null);
        setTouchMove(null);
    };

    return { onTouchStart, onTouchMove, onTouchEnd };
};

export const ConfirmationModal = ({ isOpen, onClose, onConfirm, title, message }: any) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 fade-in" style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }} onClick={onClose}>
            <div className="glass-mold w-full max-w-xs rounded-[32px] p-6 shadow-2xl border border-white/10 bg-[#1a1a1a]/90" onClick={e => e.stopPropagation()}>
                <div className="mb-4 flex flex-col items-center text-center">
                    <div className="w-14 h-14 rounded-full bg-red-500/10 flex items-center justify-center mb-4 text-red-500 border border-red-500/20 shadow-[0_0_20px_rgba(239,68,68,0.2)]">
                        <svg className="w-7 h-7" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">{message}</p>
                </div>
                <div className="flex gap-3">
                    <button onClick={onClose} className="flex-1 py-3.5 rounded-2xl bg-white/5 text-gray-300 font-bold text-sm hover:bg-white/10 transition border border-white/5">Cancel</button>
                    <button onClick={onConfirm} className="flex-1 py-3.5 rounded-2xl bg-red-500 text-white font-bold text-sm hover:bg-red-600 transition shadow-lg shadow-red-500/30">Delete</button>
                </div>
            </div>
        </div>
    );
};

export const GenericPageModal = ({ isOpen, title, songs, tiles, onClose, onPlay, onRemove, onTileClick }: any) => {
    const swipeHandlers = useSwipeDown(onClose);
    if (!isOpen) return null;
    return (
        <div 
            className={`fixed inset-0 z-[45] glass-mold rounded-none flex flex-col transition-transform duration-300 pt-safe ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
            {...swipeHandlers}
        >
            <div className="w-full flex justify-center pt-2 pb-1" onClick={onClose}>
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
            </div>
            <div className="flex items-center gap-4 p-5 pt-2 sticky top-0 z-10 border-b" style={{ borderColor: 'var(--border-dim)' }}>
                <button onClick={onClose} className="p-2 -ml-2 rounded-full hover:bg-white/10 tile-active"><svg className="w-6 h-6 text-primary-theme" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg></button>
                <h1 className="text-2xl font-bold text-primary-theme">{title}</h1>
            </div>
            <div className="space-y-4 p-5 pb-32 overflow-y-auto flex-1">
                {tiles ? (
                    <div className="grid grid-cols-2 gap-4">
                        {tiles.map((tile: any, i: number) => (
                            <div key={i} onClick={() => onTileClick(tile)} className={`relative overflow-hidden cursor-pointer tile-active group shadow-lg glass-mold border border-white/5 rounded-[24px] ${tile.height || 'h-32'}`}>
                                <div className={`absolute inset-0 bg-gradient-to-br ${tile.color || 'from-gray-800 to-gray-900'} opacity-80 group-hover:opacity-100 transition duration-500`}></div>
                                <div className="relative z-10 flex flex-col h-full justify-between p-4">
                                    {tile.icon && <div className="text-2xl">{tile.icon}</div>}
                                    {tile.subLabel && <span className="text-xs font-bold text-white uppercase tracking-wider bg-black/20 w-fit px-2 py-1 rounded-lg backdrop-blur-sm">{tile.subLabel}</span>}
                                    <span className="text-lg font-black text-white leading-tight">{tile.label || tile.title}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    songs.length === 0 ? <p className="text-center text-sec mt-10">No songs here yet.</p> :
                    songs.map((s: Song, i: number) => (
                    <div key={i} onClick={() => onPlay(songs, i)} className="flex items-center gap-4 p-2 rounded-xl hover:bg-white/10 cursor-pointer border-b" style={{ borderColor: 'var(--border-dim)' }}>
                        <img src={s.cover} className="w-12 h-12 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-sm text-primary-theme truncate">{s.title}</h4>
                            <p className="text-xs text-sec truncate">{s.artist}</p>
                        </div>
                        {onRemove ? (
                             <button onClick={(e) => { e.stopPropagation(); onRemove(i); }} className="p-2 bg-red-500/10 text-red-500 border border-red-500/20 rounded-full hover:bg-red-500 hover:text-white transition active:scale-90 shadow-sm">
                                 <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                             </button>
                         ) : (
                            <button className="text-brandRed"><svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button>
                         )}
                    </div>
                )))}
            </div>
        </div>
    );
};

export const QueueModal = ({ isOpen, onClose, queue, currentIndex, onPlay }: any) => {
    const swipeHandlers = useSwipeDown(onClose);
    return (
        <div 
            className={`fixed inset-0 z-[60] glass-mold rounded-none transition-transform duration-300 flex flex-col pt-safe ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
            {...swipeHandlers}
        >
            <div className="w-full flex justify-center pt-2 pb-1" onClick={onClose}>
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
            </div>
            <div className="p-5 pt-2 border-b flex justify-between items-center bg-transparent" style={{ borderColor: 'var(--border-dim)' }}>
                <h2 className="text-xl font-bold text-primary-theme">Playing Queue</h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10">
                    <svg className="w-6 h-6 text-primary-theme" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M19 9l-7 7-7-7"/></svg>
                </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-3 pb-32">
                {queue.length === 0 ? <p className="text-center text-sec mt-10">Queue is empty</p> : 
                    queue.map((s: Song, i: number) => (
                        <div key={i} onClick={() => { onPlay(queue, i); onClose(); }} className={`flex items-center gap-3 p-2 rounded-xl ${i === currentIndex ? 'bg-brandRed/20 border border-brandRed/50' : 'hover:bg-white/5'} cursor-pointer`}>
                            <img src={s.cover} className="w-10 h-10 rounded-lg bg-gray-800 object-cover" />
                            <div className="flex-1 min-w-0">
                                <h4 className={`text-sm font-bold truncate ${i === currentIndex ? 'text-brandRed' : 'text-primary-theme'}`}>{s.title}</h4>
                                <p className="text-xs text-sec truncate">{s.artist}</p>
                            </div>
                            {i === currentIndex && <div className="w-2 h-2 rounded-full bg-brandRed animate-pulse"></div>}
                        </div>
                    ))
                }
            </div>
        </div>
    );
};

export const AddToPlaylistModal = ({ isOpen, onClose, playlists, onAdd }: any) => {
    if(!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-6 fade-in" style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }} onClick={onClose}>
            <div className="w-full max-w-xs rounded-[32px] p-6 shadow-2xl border border-white/20 glass-mold overflow-hidden" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-black text-primary-theme">Add to Playlist</h3>
                    <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition text-primary-theme"><svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg></button>
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto no-scrollbar">
                    {playlists.length === 0 ? <p className="text-center text-sec text-sm py-4">No playlists yet.</p> :
                        playlists.map((pl: Playlist, i: number) => (
                        <div key={i} onClick={() => onAdd(i)} className="p-4 bg-white/5 rounded-2xl cursor-pointer hover:bg-white/10 active:scale-95 transition flex justify-between items-center border border-white/5 group">
                            <span className="text-primary-theme font-bold">{pl.name}</span>
                            <span className="text-xs text-primary-theme font-bold bg-white/10 px-2.5 py-1 rounded-lg group-hover:bg-white/20 transition">{pl.songs.length}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export const CreatePlaylistModal = ({ isOpen, onClose, onCreate }: any) => {
    const [name, setName] = useState("");
    if(!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-md flex items-center justify-center p-6 fade-in">
             <div className="glass-mold w-full max-w-xs rounded-super p-6 bg-gray-900/90">
                <h3 className="text-xl font-bold text-primary-theme mb-4">New Playlist</h3>
                <input 
                    autoFocus
                    type="text" 
                    placeholder="Playlist Name" 
                    className="w-full bg-white/10 border border-white/10 rounded-xl p-3 text-primary-theme mb-4 focus:outline-none focus:border-brandRed"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <div className="flex gap-3">
                    <button onClick={onClose} className="flex-1 py-3 rounded-xl bg-white/5 text-sec font-bold">Cancel</button>
                    <button onClick={() => { if(name) { onCreate(name); setName(""); onClose(); } }} className="flex-1 py-3 rounded-xl bg-brandRed text-white font-bold shadow-lg">Create</button>
                </div>
             </div>
        </div>
    );
};

export const AddArtistModal = ({ isOpen, onClose, onAdd }: any) => {
    const [name, setName] = useState("");
    if(!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-md flex items-center justify-center p-6 fade-in">
             <div className="glass-mold w-full max-w-xs rounded-super p-6 bg-gray-900/90">
                <h3 className="text-xl font-bold text-primary-theme mb-4">Add Artist</h3>
                <input 
                    autoFocus
                    type="text" 
                    placeholder="Artist Name (e.g. Arijit Singh)" 
                    className="w-full bg-white/10 border border-white/10 rounded-xl p-3 text-primary-theme mb-4 focus:outline-none focus:border-brandRed"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => { if(e.key === 'Enter' && name) { onAdd(name); setName(""); } }}
                />
                <div className="flex gap-3">
                    <button onClick={onClose} className="flex-1 py-3 rounded-xl bg-white/5 text-sec font-bold">Cancel</button>
                    <button onClick={() => { if(name) { onAdd(name); setName(""); } }} className="flex-1 py-3 rounded-xl bg-brandRed text-white font-bold shadow-lg">Add</button>
                </div>
             </div>
        </div>
    );
};

export const VolumeModal = ({ isOpen, onClose, volume, onVolumeChange }: any) => {
    if(!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-6 fade-in" style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }} onClick={onClose}>
            <div className="glass-mold w-full max-w-xs rounded-[36px] p-8 shadow-2xl border border-white/20 relative overflow-hidden" onClick={e => e.stopPropagation()}>
                <div className="absolute inset-0 bg-white/5 pointer-events-none"></div>
                <div className="relative z-10 flex flex-col items-center">
                    <div className="w-16 h-16 rounded-[24px] bg-white/10 border border-white/5 flex items-center justify-center mb-5 text-primary-theme shadow-[0_8px_16px_rgba(0,0,0,0.2)]">
                         <svg className="w-8 h-8" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M11 5L6 9H2v6h4l5 4V5z"/></svg>
                    </div>
                    <h3 className="text-2xl font-black text-primary-theme mb-8 text-center tracking-tight drop-shadow-sm">Volume</h3>
                    
                    <div className="w-full h-12 bg-black/20 rounded-[20px] relative flex items-center px-3 mb-8 shadow-inner border border-white/5">
                         <input 
                            type="range" min="0" max="100" 
                            value={volume}
                            onChange={(e) => onVolumeChange(parseInt(e.target.value))}
                            className="w-full h-2 bg-transparent rounded-full appearance-none cursor-pointer accent-white relative z-10"
                        />
                    </div>
                    
                    <button onClick={onClose} className="w-full py-4 rounded-2xl bg-white/10 text-primary-theme font-bold hover:bg-white/20 transition active:scale-95 border border-white/5 shadow-lg">Done</button>
                </div>
            </div>
        </div>
    );
};

export const SettingsModal = ({ isOpen, onClose, userProfile, isDark, toggleTheme, onOpenProfile, onOpenHistory }: any) => {
    // Dynamic background for items to ensure visibility in both modes
    const itemBg = isDark ? "bg-white/5 border-white/10" : "bg-black/5 border-black/10";
    
    return (
        <div 
            className={`fixed inset-0 z-[60] glass-mold rounded-none transform transition-transform duration-300 flex flex-col h-full pt-safe pb-safe border-l-0 border-r-0 border-b-0 overflow-x-hidden ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
        >
            <div className="p-4 pt-2 flex items-center border-b border-white/10 sticky top-0 bg-transparent" style={{ borderColor: 'var(--border-dim)' }}>
                <button onClick={onClose} className="mr-4 p-1 hover:bg-white/10 rounded-full active:scale-90 transition"><svg className="w-6 h-6 text-sec" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg></button>
                <h2 className="text-xl font-bold text-primary-theme">Settings</h2>
            </div>
            <div className="p-4 overflow-y-auto flex-1 overflow-x-hidden">
                <div className={`flex flex-col items-center justify-center py-10 mb-6 rounded-2xl border shadow-inner ${itemBg}`}>
                    <div className="deep-glass-logo mb-4" style={{ transform: 'scale(1.5)' }}>
                        <span className="logo-text-layer">Meevi</span>
                    </div>
                    <p className="text-sec text-sm font-medium tracking-wide">Liquid Glass Edition</p>
                    <div className="mt-4 text-center">
                        <h3 className="text-xl font-bold text-primary-theme">{userProfile.name}</h3>
                        <p className="text-sm text-sec">{userProfile.handle}</p>
                    </div>
                </div>
                <div className="space-y-3">
                    <div className={`flex items-center justify-between p-4 rounded-2xl border shadow-sm ${itemBg}`}>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-purple-500/20 rounded-lg"><svg className="w-5 h-5 text-purple-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg></div>
                            <span className="font-medium text-primary-theme">Dark Mode</span>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" checked={isDark} onChange={toggleTheme} />
                            <div className="w-11 h-6 bg-gray-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brandPurple"></div>
                        </label>
                    </div>
                    <div onClick={onOpenProfile} className={`flex items-center gap-4 py-4 px-4 rounded-2xl border active:scale-[0.98] transition cursor-pointer ${itemBg}`}>
                        <div className="p-2 bg-blue-500/20 rounded-lg"><svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg></div>
                        <span className="font-medium text-primary-theme">Your Information</span>
                    </div>
                    <div onClick={onOpenHistory} className={`flex items-center gap-4 py-4 px-4 rounded-2xl border active:scale-[0.98] transition cursor-pointer ${itemBg}`}>
                        <div className="p-2 bg-orange-500/20 rounded-lg"><svg className="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div>
                        <span className="font-medium text-primary-theme">History</span>
                    </div>
                </div>
                <div className="mt-10 pb-10">
                    <div className={`dev-badge rounded-2xl p-6 text-center shadow-glow relative border ${itemBg}`}>
                        <div className="absolute -top-10 -left-10 w-24 h-24 bg-brandRed opacity-20 rounded-full blur-2xl"></div>
                        <div className="absolute -bottom-10 -right-10 w-24 h-24 bg-blue-500 opacity-20 rounded-full blur-2xl"></div>
                        <p className="text-xs font-bold uppercase tracking-widest text-sec mb-2">Designed & Developed by</p>
                        <h2 className="text-2xl font-black text-primary-theme mb-1 drop-shadow-md">Rishav Raj</h2>
                        <div className="flex items-center justify-center gap-2 mt-3">
                            <span className="px-3 py-1 bg-white/10 rounded-full text-xs font-mono border border-white/10 text-primary-theme">v2.1 Pro</span>
                            <span className="px-3 py-1 bg-brandRed/20 text-brandRed rounded-full text-xs font-bold border border-brandRed/20">Final</span>
                        </div>
                    </div>
                    <p className="text-xs text-sec text-center mt-6 opacity-50">Made with ❤️ for Music Lovers</p>
                </div>
            </div>
        </div>
    );
};

export const HistorySidebar = ({ isOpen, onClose, history, onRemoveItem, onClearAll, onPlay }: any) => {
    const swipeHandlers = useSwipeDown(onClose);
    return (
        <div 
            className={`fixed inset-0 z-[70] glass-mold rounded-none transform transition-transform duration-300 flex flex-col pt-safe h-full border-l border-white/10 ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
            {...swipeHandlers}
        >
             <div className="w-full flex justify-center pt-2 pb-1" onClick={onClose}>
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
            </div>
             <div className="p-5 pt-2 flex items-center gap-4 border-b border-white/10 sticky top-0 z-10 bg-transparent" style={{ borderColor: 'var(--border-dim)' }}>
                <button onClick={onClose} className="p-2 -ml-2 rounded-full hover:bg-white/10"><svg className="w-6 h-6 text-primary-theme" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg></button>
                <div className="flex-1 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-primary-theme">History</h1>
                    {history.length > 0 && (
                        <button onClick={onClearAll} className="px-4 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold uppercase tracking-wider hover:bg-red-500/20 active:scale-95 transition">
                            Clear All
                        </button>
                    )}
                </div>
            </div>
            <div className="p-5 overflow-y-auto flex-1">
                <div className="space-y-2">
                    {history.length === 0 ? <p className="text-center text-sec mt-10">No history yet.</p> :
                        history.map((s: Song, i: number) => (
                            <div key={i} onClick={() => onPlay(history, i)} className="flex gap-3 p-2 items-center cursor-pointer hover:bg-white/5 rounded-2xl group transition-colors border border-transparent hover:border-white/5">
                                <img src={s.cover} className="w-12 h-12 rounded-xl object-cover shadow-sm" />
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-bold text-primary-theme truncate">{s.title}</p>
                                    <p className="text-xs text-sec truncate">{s.artist}</p>
                                </div>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onRemoveItem(i); }} 
                                    className="w-9 h-9 rounded-full flex items-center justify-center bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all shadow-sm active:scale-90 border border-red-500/10"
                                >
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                </button>
                            </div>
                        ))
                    }
                </div>
            </div>
        </div>
    );
};

export const ProfileEditSidebar = ({ isOpen, onClose, userProfile, onSave }: any) => {
    const [name, setName] = useState(userProfile.name);
    const [handle, setHandle] = useState(userProfile.handle);
    const swipeHandlers = useSwipeDown(onClose);

    React.useEffect(() => {
        if(isOpen) {
            setName(userProfile.name);
            setHandle(userProfile.handle);
        }
    }, [isOpen, userProfile]);

    return (
        <div 
            className={`fixed inset-0 z-[70] glass-mold rounded-none transform transition-transform duration-300 flex flex-col pt-safe h-full border-l border-white/10 ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
            {...swipeHandlers}
        >
            <div className="w-full flex justify-center pt-2 pb-1" onClick={onClose}>
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
            </div>
            <div className="p-5 pt-2 flex items-center gap-4 border-b border-white/10 sticky top-0 z-10 bg-transparent" style={{ borderColor: 'var(--border-dim)' }}>
                <button onClick={onClose} className="p-2 -ml-2 rounded-full hover:bg-white/10"><svg className="w-6 h-6 text-primary-theme" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg></button>
                <h1 className="text-2xl font-bold text-primary-theme">Your Information</h1>
            </div>
            <div className="p-5 flex flex-col gap-6">
                <div className="flex flex-col items-center mb-4">
                    <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center text-4xl mb-2 border-2 border-white/10 shadow-glow">👤</div>
                    <p className="text-blue-500 text-sm font-medium">Change Photo</p>
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-sec tracking-widest">Display Name</label>
                    <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full bg-white/10 text-primary-theme p-4 rounded-xl border border-white/10 focus:border-pink-500 focus:outline-none font-medium transition" />
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-bold uppercase text-sec tracking-widest">Handle</label>
                    <input type="text" value={handle} onChange={e => setHandle(e.target.value)} className="w-full bg-white/10 text-primary-theme p-4 rounded-xl border border-white/10 focus:border-pink-500 focus:outline-none font-medium transition" />
                </div>
                <button onClick={() => onSave(name, handle)} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 p-4 rounded-xl font-bold text-white shadow-lg active:scale-95 transition-transform mt-4">Save Changes</button>
            </div>
        </div>
    );
};