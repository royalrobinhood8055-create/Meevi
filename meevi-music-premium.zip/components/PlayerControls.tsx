import React, { useRef, useEffect } from 'react';
import { Song } from '../types';

interface MiniPlayerProps {
    song: Song | null;
    isPlaying: boolean;
    isBuffering: boolean;
    onTogglePlay: () => void;
    onNext: () => void;
    onPrev: () => void;
    onExpand: () => void;
    progress: number;
    isFullPlayerOpen: boolean;
}

export const MiniPlayer: React.FC<MiniPlayerProps> = ({ song, isPlaying, isBuffering, onTogglePlay, onNext, onPrev, onExpand, progress, isFullPlayerOpen }) => {
    if (!song) return null;

    return (
        <div 
            onClick={onExpand} 
            className={`fixed bottom-[5.5rem] left-3 right-3 glass-mold rounded-super p-2.5 flex items-center gap-2 z-40 cursor-pointer tile-active mb-safe transition-all duration-500 cubic-bezier(0.32, 0.72, 0, 1) ${isFullPlayerOpen ? 'opacity-0 translate-y-20 scale-90 pointer-events-none' : 'opacity-100 translate-y-0 scale-100 delay-100'}`}
        >
            <img src={song.cover} className="w-11 h-11 rounded-2xl bg-tertiary object-cover shadow-sm shrink-0" />
            <div className="flex-1 min-w-0 mr-1 ml-1">
                <h4 className="font-bold text-sm truncate leading-tight text-primary-theme">{song.title}</h4>
                <p className="text-sec text-[10px] truncate">{song.artist}</p>
            </div>
            
            <div className="flex items-center gap-2.5 shrink-0 pr-1">
                 <button onClick={(e) => { e.stopPropagation(); onPrev(); }} className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center active:scale-90 transition backdrop-blur-sm border border-white/5 shadow-sm hover:bg-white/20">
                    <svg className="w-4 h-4 text-primary-theme fill-current" viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>
                 </button>
    
                 <div className="relative w-10 h-10 flex items-center justify-center">
                     {isBuffering && <div className="loader absolute inset-0" style={{ width: '100%', height: '100%', borderWidth: '2px' }}></div>}
                     <button onClick={(e) => { e.stopPropagation(); onTogglePlay(); }} className="w-10 h-10 rounded-full bg-brandRed text-white flex items-center justify-center active:scale-90 transition shadow-lg shadow-brandRed/30">
                        <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24"><path d={isPlaying ? "M6 19h4V5H6v14zm8-14v14h4V5h-4z" : "M8 5v14l11-7z"}/></svg>
                     </button>
                 </div>
    
                 <button onClick={(e) => { e.stopPropagation(); onNext(); }} className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center active:scale-90 transition backdrop-blur-sm border border-white/5 shadow-sm hover:bg-white/20">
                    <svg className="w-4 h-4 text-primary-theme fill-current" viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
                 </button>
            </div>
            
            <div className="absolute bottom-0 left-4 right-4 h-[2px] bg-white/20 rounded-full overflow-hidden mb-1 pointer-events-none">
                <div className="h-full bg-brandRed transition-all duration-500" style={{ width: `${progress}%` }}></div>
            </div>
        </div>
    );
};

interface FullPlayerProps {
    isOpen: boolean;
    onClose: () => void;
    song: Song | null;
    isPlaying: boolean;
    isBuffering: boolean;
    isShuffle: boolean;
    isRepeat: boolean;
    isLiked: boolean;
    currentTime: number;
    duration: number;
    onTogglePlay: () => void;
    onNext: () => void;
    onPrev: () => void;
    onShuffle: () => void;
    onRepeat: () => void;
    onLike: () => void;
    onSeek: (percent: number) => void;
    onOpenQueue: () => void;
    onOpenVolume: () => void;
    onAddToPlaylist: () => void;
    onShare: () => void;
}

export const FullPlayer: React.FC<FullPlayerProps> = ({ 
    isOpen, onClose, song, isPlaying, isBuffering, isShuffle, isRepeat, isLiked, 
    currentTime, duration, onTogglePlay, onNext, onPrev, onShuffle, onRepeat, onLike, onSeek, 
    onOpenQueue, onOpenVolume, onAddToPlaylist, onShare 
}) => {
    const formatTime = (s: number) => { 
        if (isNaN(s)) return "0:00"; 
        const m = Math.floor(s / 60); 
        const sec = Math.floor(s % 60); 
        return `${m}:${sec < 10 ? '0' : ''}${sec}`; 
    };

    const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
    
    // Touch gesture logic
    const playerRef = useRef<HTMLDivElement>(null);
    const touchStart = useRef(0);
    const isDragging = useRef(false);

    useEffect(() => {
        const el = playerRef.current;
        if(!el) return;

        const handleStart = (e: TouchEvent) => {
            if((e.target as HTMLElement).closest('input')) return;
            isDragging.current = true;
            touchStart.current = e.touches[0].clientY;
            el.classList.remove('smooth-transition');
        };

        const handleMove = (e: TouchEvent) => {
            if(!isDragging.current) return;
            const diff = e.touches[0].clientY - touchStart.current;
            if(diff > 0) el.style.transform = `translate3d(0, ${diff}px, 0)`;
        };

        const handleEnd = (e: TouchEvent) => {
            isDragging.current = false;
            el.classList.add('smooth-transition');
            const diff = e.changedTouches[0].clientY - touchStart.current;
            el.style.transform = ''; 
            if (diff > 150) onClose();
        };

        el.addEventListener('touchstart', handleStart, {passive: true});
        el.addEventListener('touchmove', handleMove, {passive: true});
        el.addEventListener('touchend', handleEnd);

        return () => {
            el.removeEventListener('touchstart', handleStart);
            el.removeEventListener('touchmove', handleMove);
            el.removeEventListener('touchend', handleEnd);
        };
    }, [onClose]);

    useEffect(() => {
        if(isOpen && playerRef.current) playerRef.current.style.transform = '';
    }, [isOpen]);

    if (!song) return null;

    /**
     * UNIFIED BUTTON STYLE
     * - Shape: rounded-[24px] (Squircle/Samsung style)
     * - Background: Glass (white/10) with Blur
     * - Shadow: Red Glow (rgba(255,45,85, 0.25)) behind the button
     * - Border: Thin white border
     */
    const unifiedTileClass = "relative flex items-center justify-center rounded-[24px] bg-white/10 border border-white/10 backdrop-blur-xl shadow-[0_8px_24px_rgba(255,45,85,0.25)] text-primary-theme transition-all duration-300 active:scale-90 hover:bg-white/20 hover:shadow-[0_12px_32px_rgba(255,45,85,0.4)] overflow-hidden";
    
    // Active state specifically for Toggle buttons (Shuffle/Repeat)
    const activeTileClass = "bg-brandGreen/20 text-brandGreen shadow-[0_0_25px_rgba(34,197,94,0.5)] border-brandGreen/50";

    return (
        <div 
            ref={playerRef}
            className={`fixed inset-0 z-50 liquid-player-bg text-primary-theme flex flex-col smooth-transition h-full overflow-hidden pt-safe pb-safe ${isOpen ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-[60%] opacity-0 scale-[0.85] pointer-events-none'}`}
            style={{ transformOrigin: 'bottom center', transitionTimingFunction: 'cubic-bezier(0.32, 0.72, 0, 1)' }}
        >
            <div className="player-blob"></div>
            
            {/* Grab handle */}
            <div className="w-full flex justify-center pt-3 absolute top-0 z-20 pointer-events-none mt-safe">
                <div className="w-12 h-1.5 bg-white/20 rounded-full backdrop-blur-md shadow-sm"></div>
            </div>
    
            <div className="relative z-10 flex flex-col h-full px-6 pt-4 pb-8">
                
                {/* Header: Back & Share (Unified Tiles) */}
                <div className="flex justify-between items-center h-16 flex-shrink-0 z-20 mt-2">
                    <button onClick={onClose} className={`w-14 h-14 ${unifiedTileClass}`}>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    
                    <span className="text-[10px] font-bold tracking-[0.2em] opacity-60 uppercase text-primary-theme drop-shadow-sm">Now Playing</span>
                    
                    <button onClick={onShare} className={`w-14 h-14 ${unifiedTileClass}`}>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
                    </button>
                </div>
    
                {/* Album Art */}
                <div className="flex-1 min-h-0 flex items-center justify-center py-6">
                    <div className="relative w-auto h-full max-h-full aspect-square rounded-[36px] overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.6)] border border-white/10 z-10 ring-1 ring-white/5">
                         <img src={song.cover} className="w-full h-full object-cover" />
                    </div>
                </div>
    
                {/* Info & Controls */}
                <div className="flex flex-col gap-8 flex-shrink-0 mt-auto">
                    
                    {/* Title & Like (Like uses Unified Tile) */}
                    <div className="flex justify-between items-center px-1">
                        <div className="flex flex-col overflow-hidden mr-4">
                            <h2 className="text-3xl font-black truncate-2-lines leading-tight text-primary-theme drop-shadow-md tracking-tight">{song.title}</h2>
                            <p className="text-lg opacity-70 truncate font-medium mt-1 text-primary-theme">{song.artist}</p>
                        </div>
                        <button onClick={onLike} className={`w-14 h-14 flex-shrink-0 ${unifiedTileClass}`}>
                            <svg className={`w-6 h-6 ${isLiked ? 'text-brandRed filter drop-shadow-[0_0_10px_rgba(255,45,85,0.5)]' : 'text-primary-theme'}`} fill={isLiked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                        </button>
                    </div>
    
                    {/* Progress */}
                    <div className="group px-1">
                        <input 
                            type="range" 
                            min="0" 
                            max="100" 
                            value={progress || 0} 
                            onChange={(e) => onSeek(parseFloat(e.target.value))}
                            className="w-full h-1.5 rounded-full appearance-none cursor-pointer accent-white transition-all shadow-lg"
                            style={{ background: `linear-gradient(to right, white ${progress}%, rgba(255,255,255,0.15) ${progress}%)` }}
                        />
                        <div className="flex justify-between text-xs font-bold opacity-60 mt-2 font-mono tracking-wider text-primary-theme"><span>{formatTime(currentTime)}</span><span>{formatTime(duration)}</span></div>
                    </div>
    
                    {/* Main Controls - ALL SAME DESIGN (Squircle with Red Glow) */}
                    <div className="flex justify-between items-center px-2">
                        {/* Shuffle */}
                        <button onClick={onShuffle} className={`w-14 h-14 ${unifiedTileClass} ${isShuffle ? activeTileClass : ''}`}>
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l-5 5M4 4l5 5"/></svg>
                        </button>
                        
                        {/* Prev */}
                        <button onClick={onPrev} className={`w-16 h-16 ${unifiedTileClass}`}>
                            <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>
                        </button>
                        
                        {/* Play/Pause - FIXED: Uses unified Glass Theme */}
                        <div className="relative">
                             {isBuffering && <div className="loader absolute inset-[-4px] rounded-[30px] z-30" style={{ width: 'auto', height: 'auto', borderColor: 'rgba(255,255,255,0.1)', borderLeftColor: '#fff', borderWidth: '3px' }}></div>}
                             <button onClick={onTogglePlay} className={`w-20 h-20 rounded-[30px] ${unifiedTileClass} bg-white/20 hover:bg-white/30 shadow-[0_0_40px_rgba(255,45,85,0.3)]`}>
                                <svg className="w-9 h-9 fill-current ml-1 text-primary-theme" viewBox="0 0 24 24"><path d={isPlaying ? "M6 19h4V5H6v14zm8-14v14h4V5h-4z" : "M8 5v14l11-7z"}/></svg>
                            </button>
                        </div>
                        
                        {/* Next */}
                        <button onClick={onNext} className={`w-16 h-16 ${unifiedTileClass}`}>
                            <svg className="w-7 h-7 fill-current" viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
                        </button>
                        
                        {/* Repeat */}
                        <button onClick={onRepeat} className={`w-14 h-14 ${unifiedTileClass} ${isRepeat ? activeTileClass : ''}`}>
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
                        </button>
                    </div>
    
                    {/* Bottom Controls - ALL SAME DESIGN (Squircle with Red Glow) */}
                    <div className="flex justify-between items-center px-4 gap-4">
                         {/* Volume */}
                         <button onClick={onOpenVolume} className={`w-16 h-16 ${unifiedTileClass}`}>
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                         </button>
                         
                         {/* Add To Playlist (Wide Squircle) */}
                         <button onClick={onAddToPlaylist} className={`flex-1 h-16 ${unifiedTileClass} px-6 gap-2`}>
                             <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4"/></svg>
                             <span className="font-bold text-sm tracking-wide">Add Playlist</span>
                         </button>

                         {/* Queue */}
                         <button onClick={onOpenQueue} className={`w-16 h-16 ${unifiedTileClass}`}>
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};