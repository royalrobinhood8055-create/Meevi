import React, { useState, useEffect, useRef } from 'react';
import { Song, Playlist, Artist } from '../types';
import { fetchSongs } from '../services/api';

interface HomeProps {
    onPlay: (songs: Song[], index: number) => void;
    onSearch: (query: string) => void;
    savedArtists: Artist[];
    removeArtist: (index: number) => void;
    openAddArtist: () => void;
    onOpenSection: (title: string, songs?: Song[], tiles?: any[]) => void;
}

export const HomeView: React.FC<HomeProps> = ({ onPlay, onSearch, savedArtists, removeArtist, openAddArtist, onOpenSection }) => {
    const [topCharts, setTopCharts] = useState<Song[]>([]);
    const [desiHits, setDesiHits] = useState<Song[]>([]);
    const [picks, setPicks] = useState<Song[]>([]);
    const [community, setCommunity] = useState<Song[]>([]);
    const [trending, setTrending] = useState<Song[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [deleteMode, setDeleteMode] = useState<number | null>(null);
    const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    const dailyMixTiles = [
        { label: "Arijit & Friends", subLabel: "Mix 1", query: "Arijit Singh Best Songs", color: "from-pink-500 to-orange-400" },
        { label: "Punjabi Power", subLabel: "Mix 2", query: "Top Punjabi Hits 2024", color: "from-purple-600 to-blue-500" }
    ];

    const partyZoneTiles = [
        { q: 'Bollywood Club Party', icon: '🎉', label: 'Club Hits', color: 'from-yellow-500 to-orange-500' },
        { q: 'Indian Desi Hip Hop', icon: '🚀', label: 'Rap God', color: 'from-blue-500 to-indigo-600' },
        { q: 'Punjabi Party Bhangra', icon: '🥃', label: 'Patiala Peg', color: 'from-green-500 to-emerald-600' },
        { q: 'Bhojpuri Hit Songs', icon: '🥁', label: 'Desi Beats', color: 'from-red-500 to-rose-600' }
    ];

    const moodBoosterTiles = [
        { q: 'Hindi Sad Songs', title: 'Sad &\nBroken', color: 'from-gray-800 to-slate-900', iconColor: 'text-blue-300', path: 'M4.93 4.93L19.07 19.07M2 12h.01M12 2a10 10 0 0 1 7.07 2.93l-1.41 1.41A8 8 0 1 0 5.34 17.66l-1.41 1.41A10 10 0 0 1 12 2z' },
        { q: 'Bollywood Romantic Hits', title: 'Love &\nRomance', color: 'from-pink-500 to-rose-600', iconColor: 'text-white', path: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z', fill: 'currentColor' },
        { q: 'Motivation Hindi Songs', title: 'Gym &\nPower', color: 'from-blue-600 to-cyan-500', iconColor: 'text-yellow-300', path: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z', fill: 'currentColor' },
        { q: 'Road Trip Hindi Songs', title: 'Long\nDrive', color: 'from-emerald-500 to-teal-600', iconColor: 'text-white', path: 'M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2 M7 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z M5 17h2 M15 17h2', isMultiPath: true }
    ];

    useEffect(() => {
        const loadData = async () => {
            const charts = await import('../services/api').then(m => m.fetchTopCharts());
            setTopCharts(charts);
            
            setDesiHits(await fetchSongs('bollywood super hits 2025', 10));
            setPicks(await fetchSongs('arijit singh atif aslam shreya ghoshal', 10));
            setCommunity(await fetchSongs('punjabi party top hits 2025', 10));
            setTrending(await fetchSongs('pop music top hits global', 15));
            setIsLoading(false);
        };
        loadData();
    }, []);

    // Handle click outside to dismiss delete button
    useEffect(() => {
        const handleClickOutside = (e: any) => {
            if (deleteMode !== null && !e.target.closest('.artist-delete-btn')) {
                setDeleteMode(null);
            }
        };

        if (deleteMode !== null) {
            document.addEventListener('click', handleClickOutside);
        }
        
        return () => document.removeEventListener('click', handleClickOutside);
    }, [deleteMode]);

    const startPress = (index: number) => {
        pressTimer.current = setTimeout(() => {
            if (navigator.vibrate) navigator.vibrate(50);
            setDeleteMode(index);
        }, 800);
    };

    const cancelPress = () => {
        if (pressTimer.current) clearTimeout(pressTimer.current);
    };

    const SectionHeader = ({ title, onExpand }: { title: string, onExpand?: () => void }) => (
        <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold tracking-tight text-primary-theme">{title}</h2>
            {onExpand && (
                <button onClick={onExpand} className="w-10 h-10 rounded-full glass-mold flex items-center justify-center active:scale-90 transition text-primary-theme border border-white/10 shadow-sm group hover:bg-white/10">
                    <svg className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
                </button>
            )}
        </div>
    );

    const SongRow = ({ songs, title, loadingText }: { songs: Song[], title: string, loadingText: string }) => (
        <div className="mb-8">
            <SectionHeader title={title} onExpand={() => onOpenSection(title, songs)} />
            {songs.length === 0 && isLoading ? (
                <div className="text-center p-4 text-sec text-sm">{loadingText}</div>
            ) : (
                <div className="space-y-3">
                    {songs.map((song, i) => (
                        <div key={i} onClick={() => onPlay(songs, i)} className="flex items-center gap-4 p-3 glass-mold rounded-[24px] active:scale-[0.98] transition cursor-pointer">
                            <img src={song.cover} className="w-12 h-12 rounded-xl object-cover bg-gray-800" />
                            <div className="flex-1 min-w-0">
                                <h3 className="font-bold text-sm text-primary-theme truncate">{song.title}</h3>
                                <p className="text-xs text-sec truncate">{song.artist}</p>
                            </div>
                            <button className="w-8 h-8 rounded-full bg-brandRed flex items-center justify-center text-white shrink-0">
                                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );

    return (
        <div className="p-5 fade-in pb-32">
            <div className="mb-6">
                <p className="text-xs font-bold text-sec uppercase tracking-widest mb-1">Namaste India</p>
                <h1 className="text-3xl font-black text-primary-theme drop-shadow-sm">Your Vibe</h1>
            </div>

            <div className="vibe-container no-scrollbar mb-8 pb-2">
                {[
                    { label: "❤️ Romance", q: "Bollywood Romantic Songs" },
                    { label: "🕺 Bhangra", q: "Punjabi Party Hits" },
                    { label: "📼 90s Retro", q: "90s Hindi Songs Kumar Sanu Udit Narayan" },
                    { label: "☕ Desi Lofi", q: "Indian Lofi Chill" },
                    { label: "🔥 South Heat", q: "South Indian Hits" }
                ].map((vibe, i) => (
                    <button 
                        key={i} 
                        onClick={() => onSearch(vibe.q)} 
                        className="vibe-btn px-6 py-3 rounded-full glass-mold border border-white/10 text-primary-theme font-bold whitespace-nowrap active:scale-95 transition shadow-sm"
                    >
                        {vibe.label}
                    </button>
                ))}
            </div>

            <div className="mb-8">
                <SectionHeader title="Your Daily Mix" onExpand={() => onOpenSection('Your Daily Mix', undefined, dailyMixTiles)} />
                <div className="grid grid-cols-2 gap-4">
                    <div onClick={() => onSearch('Arijit Singh Best Songs')} className="h-32 rounded-super p-4 relative overflow-hidden cursor-pointer tile-active shadow-lg glass-mold group">
                        <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-orange-400 opacity-80 group-hover:opacity-100 transition duration-500"></div>
                        <div className="relative z-10 flex flex-col h-full justify-between">
                            <span className="text-xs font-bold text-white uppercase tracking-wider bg-black/20 w-fit px-2 py-1 rounded-lg backdrop-blur-sm">Mix 1</span>
                            <span className="text-xl font-black text-white leading-tight">Arijit &<br/>Friends</span>
                        </div>
                    </div>
                    <div onClick={() => onSearch('Top Punjabi Hits 2024')} className="h-32 rounded-super p-4 relative overflow-hidden cursor-pointer tile-active shadow-lg glass-mold group">
                        <div className="absolute inset-0 bg-gradient-to-bl from-purple-600 to-blue-500 opacity-80 group-hover:opacity-100 transition duration-500"></div>
                        <div className="relative z-10 flex flex-col h-full justify-between">
                            <span className="text-xs font-bold text-white uppercase tracking-wider bg-black/20 w-fit px-2 py-1 rounded-lg backdrop-blur-sm">Mix 2</span>
                            <span className="text-xl font-black text-white leading-tight">Punjabi<br/>Power</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mb-8">
                <SectionHeader title="Party Zone" onExpand={() => onOpenSection('Party Zone', undefined, partyZoneTiles)} />
                <div className="grid grid-cols-2 gap-3">
                     {[
                        { q: 'Bollywood Club Party', icon: '🎉', label: 'Club Hits', color: 'bg-yellow-500' },
                        { q: 'Indian Desi Hip Hop', icon: '🚀', label: 'Rap God', color: 'bg-blue-500' },
                        { q: 'Punjabi Party Bhangra', icon: '🥃', label: 'Patiala Peg', color: 'bg-green-500' },
                        { q: 'Bhojpuri Hit Songs', icon: '🥁', label: 'Desi Beats', color: 'bg-red-500' }
                     ].map((item, i) => (
                        <div key={i} onClick={() => onSearch(item.q)} className="p-4 rounded-[28px] glass-mold bg-white/5 active:scale-95 transition cursor-pointer flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full ${item.color} flex items-center justify-center text-xl`}>{item.icon}</div>
                            <div className="font-bold text-sm text-primary-theme">{item.label}</div>
                        </div>
                     ))}
                </div>
            </div>

            <div className="mb-8">
                <SectionHeader title="India's Top 20" onExpand={() => onOpenSection("India's Top 20", topCharts)} />
                <div className="flex overflow-x-auto space-x-4 pb-4 no-scrollbar min-h-[160px]">
                    {isLoading && topCharts.length === 0 ? <div className="text-sec text-sm p-2">Loading India's Top Songs...</div> :
                        topCharts.slice(0, 20).map((song, i) => (
                            <div key={i} onClick={() => onPlay(topCharts, i)} className="flex-shrink-0 w-40 group cursor-pointer tile-active">
                                <div className="relative aspect-square rounded-super overflow-hidden shadow-lg mb-3 bg-tertiary glass-mold">
                                    <img src={song.cover} className="w-full h-full object-cover" />
                                </div>
                                <h3 className="font-bold text-sm leading-tight truncate text-primary-theme">{song.title}</h3>
                                <p className="text-sec text-xs truncate mt-0.5">{song.artist}</p>
                            </div>
                        ))
                    }
                </div>
            </div>

            <div className="mb-8">
                <SectionHeader title="Mood Booster" onExpand={() => onOpenSection('Mood Booster', undefined, moodBoosterTiles)} />
                <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                    {[
                        { q: 'Hindi Sad Songs', title: 'Sad &\nBroken', from: 'from-gray-800', to: 'to-slate-900', iconColor: 'text-blue-300', path: 'M4.93 4.93L19.07 19.07M2 12h.01M12 2a10 10 0 0 1 7.07 2.93l-1.41 1.41A8 8 0 1 0 5.34 17.66l-1.41 1.41A10 10 0 0 1 12 2z' },
                        { q: 'Bollywood Romantic Hits', title: 'Love &\nRomance', from: 'from-pink-500', to: 'to-rose-600', iconColor: 'text-white', path: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z', fill: 'currentColor' },
                        { q: 'Motivation Hindi Songs', title: 'Gym &\nPower', from: 'from-blue-600', to: 'to-cyan-500', iconColor: 'text-yellow-300', path: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z', fill: 'currentColor' },
                        { q: 'Road Trip Hindi Songs', title: 'Long\nDrive', from: 'from-emerald-500', to: 'to-teal-600', iconColor: 'text-white', path: 'M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2 M7 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z M5 17h2 M15 17h2', isMultiPath: true }
                    ].map((item, i) => (
                         <div key={i} onClick={() => onSearch(item.q)} className="min-w-[140px] h-36 rounded-[28px] relative overflow-hidden cursor-pointer tile-active group shadow-lg glass-mold border border-white/5 gpu-accelerated">
                            <div className={`absolute inset-0 bg-gradient-to-br ${item.from} ${item.to} opacity-90 group-hover:scale-110 transition-transform duration-700 will-change-transform`}></div>
                            <div className="absolute top-3 left-3 w-10 h-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/10 z-10">
                                <svg className={`w-5 h-5 ${item.iconColor}`} fill={item.fill || "none"} stroke="currentColor" strokeWidth={item.fill ? "0" : "2"} viewBox="0 0 24 24">
                                    {item.isMultiPath ? (
                                        <>
                                            <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M5 17h2"/><path d="M15 17h2"/>
                                        </>
                                    ) : <path d={item.path}/>}
                                </svg>
                            </div>
                            <div className="absolute bottom-4 left-4 z-10">
                                <h3 className="text-lg font-black text-white leading-tight tracking-tight whitespace-pre-line drop-shadow-md" style={{ transform: 'translateZ(0)' }}>{item.title}</h3>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold tracking-tight text-primary-theme">Your Artists</h2>
                    <span className="text-xs text-sec">Hold to delete</span>
                </div>
                <div className="flex gap-4 overflow-x-auto no-scrollbar p-4">
                    {savedArtists.map((artist, i) => (
                        <div key={i} className="relative group flex-shrink-0"
                            onTouchStart={() => startPress(i)} onMouseDown={() => startPress(i)}
                            onTouchEnd={cancelPress} onMouseUp={cancelPress} onMouseLeave={cancelPress}
                            onClick={(e) => { 
                                if(deleteMode === i) {
                                    e.stopPropagation(); // Prevent immediate dismissal by document listener
                                    return; 
                                }
                                onSearch(artist.name); 
                            }}
                        >
                            <div className="flex flex-col items-center gap-2 cursor-pointer active:scale-90 transition transform duration-200">
                                <div className="w-24 h-24 rounded-[24px] glass-mold border border-white/10 overflow-hidden shadow-lg relative select-none">
                                    <img src={artist.img} className="w-full h-full object-cover pointer-events-none" />
                                </div>
                                <span className="text-xs font-bold text-primary-theme truncate w-24 text-center select-none">{artist.name}</span>
                            </div>
                            {deleteMode === i && (
                                <button className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full text-white flex items-center justify-center shadow-lg z-20 artist-delete-btn animate-bounce" onClick={(e) => { e.stopPropagation(); removeArtist(i); setDeleteMode(null); }}>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
                                </button>
                            )}
                        </div>
                    ))}
                    <div onClick={openAddArtist} className="flex flex-col items-center gap-2 cursor-pointer active:scale-90 transition transform duration-200 flex-shrink-0">
                        <div className="w-24 h-24 rounded-[24px] glass-mold border-2 border-dashed flex items-center justify-center shadow-lg hover:bg-white/5 transition-colors" style={{ borderColor: 'var(--border-dim)' }}>
                            <svg className="w-8 h-8 text-sec" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4"/></svg>
                        </div>
                        <span className="text-xs font-bold text-sec">Add</span>
                    </div>
                </div>
            </div>

            <SongRow songs={desiHits} title="Desi Hits" loadingText="Loading Bollywood Hits..." />
            <SongRow songs={picks} title="Picks for You" loadingText="Loading Your Picks..." />
            <SongRow songs={community} title="Trending Community" loadingText="Loading Trending..." />
            <SongRow songs={trending} title="Trending for You" loadingText="Loading Global Hits..." />

            <div className="h-24"></div> 
        </div>
    );
};

interface SearchProps {
    onPlay: (songs: Song[], index: number) => void;
    performSearch: (query: string) => void;
    searchResults: Song[];
    isSearching: boolean;
    initialQuery: string;
}

export const SearchView: React.FC<SearchProps> = ({ onPlay, performSearch, searchResults, isSearching, initialQuery }) => {
    const [query, setQuery] = useState(initialQuery);
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        setQuery(initialQuery);
        if(inputRef.current && initialQuery) inputRef.current.value = initialQuery;
    }, [initialQuery]);

    const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        setQuery(val);
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(() => {
            if (val.length > 2) performSearch(val);
        }, 600);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            performSearch(query);
            e.currentTarget.blur();
        }
    };

    return (
        <div className="p-5 h-full flex flex-col fade-in">
            <div className="relative mb-6">
                <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <input 
                    ref={inputRef}
                    id="search-input"
                    type="text" 
                    placeholder="Search any song..." 
                    className="w-full glass-mold text-primary-theme py-4 pl-12 pr-12 rounded-super font-medium focus:outline-none placeholder-gray-400 text-sm focus:border-brandRed transition-colors shadow-sm"
                    onChange={handleInput}
                    onKeyDown={handleKeyDown}
                    defaultValue={initialQuery}
                />
                {query.length > 0 && (
                    <button 
                        onClick={() => { setQuery(''); if(inputRef.current) inputRef.current.value = ''; }} 
                        className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/5 text-primary-theme backdrop-blur-md border border-white/10 shadow-sm"
                    >
                         <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                )}
            </div>
            
            <div className="mt-2 pb-32 flex-1">
                {query.length === 0 ? (
                    <div id="browse-categories">
                        <h3 className="text-md font-bold mb-4 text-primary-theme drop-shadow-sm">Browse</h3>
                        <div className="grid grid-cols-2 gap-4">
                            {[
                                { name: "Pop", color: "from-purple-600 to-blue-600", q: "Top Pop Songs" },
                                { name: "Hip-Hop", color: "from-red-500 to-orange-600", q: "Top Hip Hop Songs" },
                                { name: "Bollywood", color: "from-green-600 to-teal-600", q: "Bollywood Hits" },
                                { name: "Lofi", color: "from-blue-800 to-indigo-900", q: "Lofi Study" }
                            ].map((cat, i) => (
                                <div key={i} onClick={() => performSearch(cat.q)} className={`h-28 bg-gradient-to-br ${cat.color} rounded-super flex p-4 font-bold text-white items-start text-lg shadow-lg relative overflow-hidden cursor-pointer tile-active glass-mold`}>
                                    <span className="relative z-10">{cat.name}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {searchResults.length > 0 && !isSearching && (
                            <div className="mb-4">
                                <button 
                                    onClick={() => onPlay(searchResults, 0)} 
                                    className="w-full py-3 bg-brandRed rounded-2xl font-bold text-white shadow-lg active:scale-95 transition flex items-center justify-center gap-2"
                                >
                                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                                    Play All ({searchResults.length})
                                </button>
                            </div>
                        )}
                        {searchResults.length === 0 && !isSearching ? (
                            <p className="text-center text-sec mt-4">No songs found.</p>
                        ) : (
                            searchResults.map((song, i) => (
                                <div key={i} onClick={() => onPlay(searchResults, i)} className="flex items-center gap-4 active:bg-tertiary/50 p-2 rounded-super cursor-pointer hover:bg-tertiary glass-mold mb-2 tile-active">
                                    <img src={song.cover} className="w-14 h-14 rounded-2xl object-cover bg-gray-800" />
                                    <div className="flex-1 min-w-0">
                                        <h3 className="font-bold text-sm truncate text-primary-theme">{song.title}</h3>
                                        <p className="text-sec text-xs truncate">{song.artist}</p>
                                    </div>
                                    <svg className="w-5 h-5 text-sec" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                </div>
                            ))
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

interface LibraryProps {
    playlists: Playlist[];
    likedSongs: Song[];
    onOpenLiked: () => void;
    onOpenPlaylist: (index: number) => void;
    onCreatePlaylist: () => void;
    onDeletePlaylist: (index: number) => void;
    onSwitchTab: (tab: any) => void;
}

export const LibraryView: React.FC<LibraryProps> = ({ playlists, likedSongs, onOpenLiked, onOpenPlaylist, onCreatePlaylist, onDeletePlaylist, onSwitchTab }) => {
    return (
        <div className="p-5 fade-in">
            <div className="flex items-center gap-4 mb-6">
                <h1 className="text-3xl font-bold text-primary-theme drop-shadow-sm">Library</h1>
                <div className="ml-auto flex gap-4 text-sec">
                   <button onClick={() => onSwitchTab('search')} className="p-2 glass-mold rounded-full hover:bg-white/10 transition tile-active"><svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg></button>
                   <button onClick={onCreatePlaylist} className="p-2 glass-mold rounded-full hover:bg-white/10 transition tile-active"><svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4"/></svg></button>
                </div>
            </div>
            <div className="space-y-3">
                <div onClick={onOpenLiked} className="flex items-center gap-4 active:bg-tertiary/50 p-3 rounded-super -mx-2 transition cursor-pointer hover:bg-tertiary glass-mold mb-2 tile-active">
                    <div className="w-14 h-14 rounded-2xl overflow-hidden flex-shrink-0 shadow-md bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center"><svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></div>
                    <div className="flex-1 min-w-0"><h3 className="font-bold text-md text-purple-400">Liked Songs</h3><p className="text-sec text-xs truncate flex items-center gap-1 mt-0.5">{likedSongs.length} songs</p></div>
                </div>
                
                {playlists.map((pl, i) => (
                    <div key={i} className="flex items-center gap-4 active:bg-tertiary/50 p-3 rounded-super -mx-2 transition cursor-pointer hover:bg-tertiary glass-mold mb-2 tile-active" onClick={() => onOpenPlaylist(i)}>
                        <div className="w-14 h-14 rounded-2xl overflow-hidden flex-shrink-0 shadow-md bg-gray-800 flex items-center justify-center text-xl font-bold text-gray-500">{pl.name[0]}</div>
                        <div className="flex-1 min-w-0"><h3 className="font-bold text-md text-primary-theme">{pl.name}</h3><p className="text-sec text-xs truncate flex items-center gap-1 mt-0.5">{pl.songs.length} songs</p></div>
                        <button onClick={(e) => { e.stopPropagation(); onDeletePlaylist(i); }} className="p-2.5 bg-red-500/10 text-red-500 border border-red-500/20 rounded-full hover:bg-red-500 hover:text-white transition active:scale-90 shadow-sm"><svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                    </div>
                ))}
            </div>
        </div>
    );
};