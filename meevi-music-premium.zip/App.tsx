import React, { useState, useEffect, useRef, useCallback } from 'react';
import { HomeView, SearchView, LibraryView } from './components/Views';
import { MiniPlayer, FullPlayer } from './components/PlayerControls';
import { 
    GenericPageModal, QueueModal, AddToPlaylistModal, CreatePlaylistModal, 
    AddArtistModal, VolumeModal, SettingsModal, HistorySidebar, ProfileEditSidebar,
    ConfirmationModal
} from './components/Modals';
import { Song, Playlist, Artist, UserProfile, ViewType } from './types';
import { getYoutubeId, fetchSongs } from './services/api';

// Global declaration for YouTube API
declare global {
    interface Window {
        onYouTubeIframeAPIReady: () => void;
        YT: any;
    }
}

const App: React.FC = () => {
    
    // --- STATE ---
    const [songs, setSongs] = useState<Song[]>([]);
    const [currentSongIndex, setCurrentSongIndex] = useState(-1);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isBuffering, setIsBuffering] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [isShuffle, setIsShuffle] = useState(false);
    const [isRepeat, setIsRepeat] = useState(false);
    const [volume, setVolume] = useState(100); // Volume State
    
    // Non-persistent Data (Reset on reload)
    const [playlists, setPlaylists] = useState<Playlist[]>([{ name: "My Favorites", songs: [] }]);
    const [likedSongs, setLikedSongs] = useState<Song[]>([]);
    const [history, setHistory] = useState<Song[]>([]);
    const [savedArtists, setSavedArtists] = useState<Artist[]>([]);
    const [userProfile, setUserProfile] = useState<UserProfile>({ name: "Meevi User", handle: "@meevi_user" });
    const [theme, setTheme] = useState('theme-dark');

    // UI State
    const [view, setView] = useState<ViewType>('home');
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Song[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [showFullPlayer, setShowFullPlayer] = useState(false);
    
    // Modals
    const [showSettings, setShowSettings] = useState(false);
    const [showHistory, setShowHistory] = useState(false);
    const [showProfileEdit, setShowProfileEdit] = useState(false);
    const [showQueue, setShowQueue] = useState(false);
    const [showVolume, setShowVolume] = useState(false);
    const [showAddToPlaylist, setShowAddToPlaylist] = useState(false);
    const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
    const [showAddArtist, setShowAddArtist] = useState(false);
    
    // Confirmation Modal State
    const [confirmModal, setConfirmModal] = useState<{
        isOpen: boolean;
        title: string;
        message: string;
        onConfirm: () => void;
    }>({ isOpen: false, title: '', message: '', onConfirm: () => {} });

    // Generic Page State
    const [genericPage, setGenericPage] = useState<{
        isOpen: boolean;
        type: 'liked' | 'playlist' | 'custom' | 'tiles' | null;
        playlistIndex: number;
        customTitle?: string;
        customSongs?: Song[];
        customTiles?: any[];
    }>({ isOpen: false, type: null, playlistIndex: -1 });

    // Refs
    const ytPlayerRef = useRef<any>(null);
    const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);

    // --- EFFECT: Theme Only (No Saving) ---
    useEffect(() => {
        document.body.className = `${theme} h-screen flex flex-col overflow-hidden select-none supports-[height:100dvh]:h-[100dvh]`;
    }, [theme]);

    // --- YOUTUBE PLAYER ---
    useEffect(() => {
        window.onYouTubeIframeAPIReady = () => {
            ytPlayerRef.current = new window.YT.Player('yt-player-container', {
                height: '1', width: '1',
                playerVars: { playsinline: 1, controls: 0, disablekb: 1, fs: 0, rel: 0, iv_load_policy: 3 },
                events: {
                    onReady: (e: any) => e.target.setVolume(volume),
                    onStateChange: onPlayerStateChange,
                    onError: () => { console.error("Player Error"); playNext(true); }
                }
            });
        };
        if (window.YT && window.YT.Player) window.onYouTubeIframeAPIReady();
    }, []);

    const onPlayerStateChange = (event: any) => {
        const state = event.data;
        if (state === window.YT.PlayerState.BUFFERING) setIsBuffering(true);
        else setIsBuffering(false);

        if (state === window.YT.PlayerState.PLAYING) {
            setIsPlaying(true);
            startProgressLoop();
        } else if (state === window.YT.PlayerState.PAUSED) {
            setIsPlaying(false);
            stopProgressLoop();
        } else if (state === window.YT.PlayerState.ENDED) {
            setIsPlaying(false);
            stopProgressLoop();
            playNext(true);
        }
    };

    const startProgressLoop = () => {
        if (progressInterval.current) clearInterval(progressInterval.current);
        progressInterval.current = setInterval(() => {
            if (ytPlayerRef.current && ytPlayerRef.current.getCurrentTime) {
                setCurrentTime(ytPlayerRef.current.getCurrentTime());
                setDuration(ytPlayerRef.current.getDuration());
            }
        }, 500);
    };

    const stopProgressLoop = () => {
        if (progressInterval.current) clearInterval(progressInterval.current);
    };

    const updateVolume = (newVol: number) => {
        setVolume(newVol);
        if (ytPlayerRef.current && ytPlayerRef.current.setVolume) {
            ytPlayerRef.current.setVolume(newVol);
        }
    };

    // --- PLAYBACK ---
    const preloadNextSong = async () => {
        if(songs.length === 0) return;
        let nextIndex = isShuffle ? Math.floor(Math.random() * songs.length) : currentSongIndex + 1;
        if (nextIndex < songs.length) {
            let s = songs[nextIndex];
            if(!s.ytId) {
                const id = await getYoutubeId(s.searchQuery) || await getYoutubeId(`${s.title} ${s.artist}`);
                if(id) {
                    const newSongs = [...songs];
                    newSongs[nextIndex].ytId = id;
                    setSongs(newSongs);
                }
            }
        }
    };

    const playSong = async (newSongs: Song[], index: number) => {
        setSongs(newSongs);
        setCurrentSongIndex(index);
        const song = newSongs[index];
        
        setHistory(prev => {
             const filtered = prev.filter(s => s.title !== song.title || s.artist !== song.artist);
             return [song, ...filtered].slice(0, 50);
        });
        
        setShowFullPlayer(true);
        setIsBuffering(true);

        let videoId = song.ytId;
        if (!videoId) {
            videoId = await getYoutubeId(song.searchQuery);
            if (!videoId) videoId = await getYoutubeId(`${song.title} ${song.artist}`);
            
            if (videoId) {
                const updatedSongs = [...newSongs];
                updatedSongs[index].ytId = videoId;
                setSongs(updatedSongs);
            }
        }

        if (videoId && ytPlayerRef.current) {
            ytPlayerRef.current.loadVideoById(videoId);
            setIsBuffering(false);
            setTimeout(preloadNextSong, 3000);
        } else {
            playNext(true);
        }
    };

    const togglePlay = () => {
        if (!ytPlayerRef.current) return;
        if (isPlaying) ytPlayerRef.current.pauseVideo();
        else ytPlayerRef.current.playVideo();
    };

    const playNext = (auto: boolean) => {
        if (songs.length === 0) return;
        if (auto && isRepeat) {
            ytPlayerRef.current.seekTo(0);
            return;
        }
        let nextIndex = isShuffle ? Math.floor(Math.random() * songs.length) : currentSongIndex + 1;
        if (nextIndex < songs.length) playSong(songs, nextIndex);
        else if(!auto) playSong(songs, 0);
    };

    const playPrev = () => {
        if (songs.length === 0) return;
        if (currentTime > 3) {
            ytPlayerRef.current.seekTo(0);
            return;
        }
        let prevIndex = currentSongIndex - 1;
        if (prevIndex < 0) prevIndex = songs.length - 1;
        playSong(songs, prevIndex);
    };

    const seekTo = (percent: number) => {
        if (ytPlayerRef.current) {
            const time = (percent / 100) * duration;
            ytPlayerRef.current.seekTo(time, true);
        }
    };

    // --- SEARCH & DATA ---
    const handleSearch = async (query: string) => {
        if (!query) return;
        setIsSearching(true);
        setView('search');
        setSearchQuery(query);
        const results = await fetchSongs(query);
        setSearchResults(results);
        setIsSearching(false);
    };

    const toggleLike = () => {
        const song = songs[currentSongIndex];
        if (!song) return;
        const exists = likedSongs.some(s => s.title === song.title && s.artist === song.artist);
        setLikedSongs(exists ? likedSongs.filter(s => s.title !== song.title) : [song, ...likedSongs]);
    };

    const addArtist = async (name: string) => {
         const results = await fetchSongs(name, 1);
         let img = "https://via.placeholder.com/150";
         if(results.length > 0) img = results[0].cover.replace('600x600bb', '300x300bb');
         setSavedArtists([...savedArtists, { name, img }]);
         setShowAddArtist(false);
    };

    const removeArtist = (index: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Remove Artist",
            message: `Remove "${savedArtists[index].name}" from your artists?`,
            onConfirm: () => {
                const n = [...savedArtists];
                n.splice(index, 1);
                setSavedArtists(n);
                setConfirmModal(prev => ({...prev, isOpen: false}));
            }
        });
    };

    const removeHistoryItem = (index: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Remove Song",
            message: "Remove this song from history?",
            onConfirm: () => {
                const newHistory = [...history];
                newHistory.splice(index, 1);
                setHistory(newHistory);
                setConfirmModal(prev => ({...prev, isOpen: false}));
            }
        });
    };

    const clearHistory = () => {
        setConfirmModal({
            isOpen: true,
            title: "Clear History",
            message: "Are you sure you want to clear your entire listening history?",
            onConfirm: () => {
                setHistory([]);
                setConfirmModal(prev => ({...prev, isOpen: false}));
            }
        });
    };

    const deletePlaylist = (index: number) => {
        setConfirmModal({
            isOpen: true,
            title: "Delete Playlist",
            message: `Are you sure you want to delete "${playlists[index].name}"?`,
            onConfirm: () => {
                const n = [...playlists];
                n.splice(index, 1);
                setPlaylists(n);
                setConfirmModal(prev => ({...prev, isOpen: false}));
            }
        });
    };

    useEffect(() => {
        const handleBack = () => {
             if(showFullPlayer) setShowFullPlayer(false);
             else if(genericPage.isOpen) setGenericPage(prev => ({...prev, isOpen: false}));
        };
    }, [showFullPlayer, genericPage]);

    const activateSearch = () => {
        setView('search');
        setTimeout(() => {
            const el = document.getElementById('search-input');
            if(el) { el.focus(); el.click(); }
        }, 50);
    };

    // Generic Page Props logic
    let genericSongs: Song[] = [];
    let genericTiles: any[] | undefined = undefined;
    let genericTitle = '';
    let genericOnRemove: ((index: number) => void) | undefined = undefined;

    if (genericPage.isOpen) {
        if (genericPage.type === 'liked') {
            genericSongs = likedSongs;
            genericTitle = 'Liked Songs';
            genericOnRemove = (index: number) => {
                setConfirmModal({
                    isOpen: true,
                    title: "Remove Song",
                    message: "Remove from Liked Songs?",
                    onConfirm: () => {
                        const newLiked = [...likedSongs];
                        newLiked.splice(index, 1);
                        setLikedSongs(newLiked);
                        setConfirmModal(prev => ({...prev, isOpen: false}));
                    }
                });
            };
        } else if (genericPage.type === 'playlist' && genericPage.playlistIndex > -1) {
            const pl = playlists[genericPage.playlistIndex];
            if (pl) {
                 genericSongs = pl.songs;
                 genericTitle = pl.name;
                 genericOnRemove = (index: number) => {
                     setConfirmModal({
                         isOpen: true,
                         title: "Remove from Playlist",
                         message: `Remove "${pl.songs[index].title}" from playlist?`,
                         onConfirm: () => {
                             const newPlaylists = [...playlists];
                             newPlaylists[genericPage.playlistIndex].songs.splice(index, 1);
                             setPlaylists(newPlaylists);
                             setConfirmModal(prev => ({...prev, isOpen: false}));
                         }
                     });
                 };
            }
        } else if (genericPage.type === 'custom' && genericPage.customSongs) {
            genericSongs = genericPage.customSongs;
            genericTitle = genericPage.customTitle || 'Songs';
        } else if (genericPage.type === 'tiles' && genericPage.customTiles) {
            genericTiles = genericPage.customTiles;
            genericTitle = genericPage.customTitle || 'Section';
        }
    }

    const handleTileClick = async (tile: any) => {
        const q = tile.query || tile.q;
        if (q) {
            // Optimistic UI update or loading state could be added here
            const songs = await fetchSongs(q, 25);
            setGenericPage({
                isOpen: true,
                type: 'custom',
                playlistIndex: -1,
                customTitle: tile.label || tile.title,
                customSongs: songs
            });
        }
    };

    const currentSong = currentSongIndex >= 0 && songs[currentSongIndex] ? songs[currentSongIndex] : null;

    return (
        <>
            <div className="ambient-blob blob-1"></div>
            <div className="ambient-blob blob-2"></div>
            <div id="yt-player-container" style={{ position: 'absolute', top: '-9999px', opacity: 0, pointerEvents: 'none' }}></div>

            <header className="px-6 py-4 pt-safe z-40 sticky top-0 pointer-events-none">
                <div className="glass-mold w-full flex items-center justify-between px-5 py-3 h-16 rounded-[24px] pointer-events-auto shadow-lg">
                    <div className="flex items-center gap-1 cursor-pointer active:scale-95 transition-transform" onClick={() => setView('home')}>
                        <div className="deep-glass-logo">
                            <span className="logo-text-layer">Meevi</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <button onClick={activateSearch} className="p-2.5 rounded-full hover:bg-white/10 transition shadow-sm border border-white/10 text-primary-theme">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        </button>
                        <button onClick={() => setShowSettings(true)} className="p-2.5 rounded-full hover:bg-white/10 transition shadow-sm border border-white/10">
                            <svg className="w-5 h-5 text-primary-theme" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        </button>
                    </div>
                </div>
            </header>

            <main className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar relative z-10 pt-2 pb-36">
                <div className={view === 'home' ? 'block' : 'hidden'}>
                    <HomeView 
                        onPlay={playSong} 
                        onSearch={handleSearch} 
                        savedArtists={savedArtists}
                        removeArtist={removeArtist}
                        openAddArtist={() => setShowAddArtist(true)}
                        onOpenSection={(title: string, songs?: Song[], tiles?: any[]) => setGenericPage({
                            isOpen: true,
                            type: tiles ? 'tiles' : 'custom',
                            playlistIndex: -1,
                            customTitle: title,
                            customSongs: songs,
                            customTiles: tiles
                        })}
                    />
                </div>
                <div className={`${view === 'search' ? 'block' : 'hidden'} h-full`}>
                    <SearchView 
                        onPlay={playSong} 
                        performSearch={handleSearch} 
                        searchResults={searchResults} 
                        isSearching={isSearching}
                        initialQuery={searchQuery}
                    />
                </div>
                <div className={view === 'library' ? 'block' : 'hidden'}>
                    <LibraryView 
                        playlists={playlists}
                        likedSongs={likedSongs}
                        onOpenLiked={() => setGenericPage({ isOpen: true, type: 'liked', playlistIndex: -1 })}
                        onOpenPlaylist={(i) => setGenericPage({ isOpen: true, type: 'playlist', playlistIndex: i })}
                        onCreatePlaylist={() => setShowCreatePlaylist(true)}
                        onDeletePlaylist={deletePlaylist}
                        onSwitchTab={setView}
                    />
                </div>
            </main>

            {/* Navigation */}
            <nav className="glass-mold rounded-t-super fixed bottom-0 w-full pb-safe pt-2 pb-2 z-30 border-b-0 border-x-0">
                <div className="flex justify-around items-center">
                    <button id="nav-home" onClick={() => setView('home')} className={`flex flex-col items-center gap-1 p-2 transition-colors duration-200 group active:scale-90 ${view === 'home' ? 'text-brandRed' : 'text-sec'}`}>
                        <svg className="w-6 h-6 transition-all duration-200" fill="currentColor" viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
                        <span className="text-[10px] font-medium">Home</span>
                    </button>
                    <button id="nav-library" onClick={() => setView('library')} className={`flex flex-col items-center gap-1 p-2 transition-colors duration-200 group active:scale-90 ${view === 'library' ? 'text-brandRed' : 'text-sec'}`}>
                        <svg className="w-6 h-6 transition-all duration-200" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/></svg>
                        <span className="text-[10px] font-medium">Library</span>
                    </button>
                    <button id="nav-search" onClick={activateSearch} className={`flex flex-col items-center gap-1 p-2 transition-colors duration-200 group active:scale-90 ${view === 'search' ? 'text-brandRed' : 'text-sec'}`}>
                        <svg className="w-6 h-6 transition-all duration-200" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        <span className="text-[10px] font-medium">Search</span>
                    </button>
                </div>
            </nav>

            <MiniPlayer 
                song={currentSong} 
                isPlaying={isPlaying} 
                isBuffering={isBuffering}
                onTogglePlay={togglePlay} 
                onNext={() => playNext(false)} 
                onPrev={playPrev} 
                onExpand={() => setShowFullPlayer(true)}
                progress={duration > 0 ? (currentTime / duration) * 100 : 0}
                isFullPlayerOpen={showFullPlayer}
            />

            <FullPlayer 
                isOpen={showFullPlayer}
                onClose={() => setShowFullPlayer(false)}
                song={currentSong}
                isPlaying={isPlaying}
                isBuffering={isBuffering}
                isShuffle={isShuffle}
                isRepeat={isRepeat}
                isLiked={currentSong ? likedSongs.some(s => s.title === currentSong.title) : false}
                currentTime={currentTime}
                duration={duration}
                onTogglePlay={togglePlay}
                onNext={() => playNext(false)}
                onPrev={playPrev}
                onShuffle={() => setIsShuffle(!isShuffle)}
                onRepeat={() => setIsRepeat(!isRepeat)}
                onLike={toggleLike}
                onSeek={seekTo}
                onOpenQueue={() => setShowQueue(true)}
                onOpenVolume={() => setShowVolume(true)}
                onAddToPlaylist={() => setShowAddToPlaylist(true)}
                onShare={async () => {
                     if (currentSong) {
                         try { await navigator.share({ title: 'Meevi', text: `Listening to ${currentSong.title}`, url: window.location.href }); } 
                         catch(e) { alert("Copied!"); }
                     }
                }}
            />

            {/* Modals */}
            <GenericPageModal 
                isOpen={genericPage.isOpen} 
                title={genericTitle} 
                songs={genericSongs} 
                tiles={genericTiles}
                onClose={() => setGenericPage(prev => ({...prev, isOpen: false}))} 
                onPlay={(s: Song[], i: number) => playSong(s, i)}
                onRemove={genericOnRemove}
                onTileClick={handleTileClick}
            />
            
            <QueueModal 
                isOpen={showQueue} 
                onClose={() => setShowQueue(false)} 
                queue={songs} 
                currentIndex={currentSongIndex}
                onPlay={(s: Song[], i: number) => playSong(s, i)}
            />

            <ConfirmationModal 
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal(prev => ({...prev, isOpen: false}))}
                onConfirm={confirmModal.onConfirm}
                title={confirmModal.title}
                message={confirmModal.message}
            />

            <AddToPlaylistModal 
                isOpen={showAddToPlaylist} 
                onClose={() => setShowAddToPlaylist(false)} 
                playlists={playlists}
                onAdd={(index: number) => { 
                    if(currentSong) {
                        const newPl = [...playlists];
                        newPl[index].songs.push(currentSong);
                        setPlaylists(newPl);
                        setShowAddToPlaylist(false);
                    }
                }}
            />

            <CreatePlaylistModal 
                isOpen={showCreatePlaylist}
                onClose={() => setShowCreatePlaylist(false)}
                onCreate={(name: string) => setPlaylists([...playlists, { name, songs: [] }])}
            />

            <AddArtistModal 
                isOpen={showAddArtist}
                onClose={() => setShowAddArtist(false)}
                onAdd={addArtist}
            />

            <VolumeModal 
                isOpen={showVolume}
                onClose={() => setShowVolume(false)}
                volume={volume}
                onVolumeChange={updateVolume}
            />

            <SettingsModal 
                isOpen={showSettings}
                onClose={() => setShowSettings(false)}
                userProfile={userProfile}
                isDark={theme === 'theme-dark'}
                toggleTheme={() => setTheme(theme === 'theme-dark' ? 'theme-light' : 'theme-dark')}
                onOpenProfile={() => setShowProfileEdit(true)}
                onOpenHistory={() => setShowHistory(true)}
            />

            <HistorySidebar 
                isOpen={showHistory}
                onClose={() => setShowHistory(false)}
                history={history}
                onRemoveItem={removeHistoryItem}
                onClearAll={clearHistory}
                onPlay={(s: Song[], i: number) => playSong(s, i)}
            />

            <ProfileEditSidebar 
                isOpen={showProfileEdit}
                onClose={() => setShowProfileEdit(false)}
                userProfile={userProfile}
                onSave={(name: string, handle: string) => { setUserProfile({name, handle}); setShowProfileEdit(false); }}
            />
        </>
    );
};

export default App;