import { Song } from '../types';

// Multiple keys for redundancy. New key is prioritized.
const YT_API_KEYS = [
    "AIzaSyDokFdtmqsk0jgy6Yju6lZxJyUwD37qvGA", // New Key (Priority)
    "AIzaSyDGwqQ8f4btABJaPLnldiLmQQCusAfQN2I"  // Backup Key
];

// Fallback instances for Piped API (No API Key needed)
const PIPED_INSTANCES = [
    "https://pipedapi.kavin.rocks",
    "https://api.piped.ot.ax",
    "https://pipedapi.moomoo.me",
    "https://pa.il.ax"
];

const searchPiped = async (query: string): Promise<string | null> => {
    for (const instance of PIPED_INSTANCES) {
        try {
            const res = await fetch(`${instance}/search?q=${encodeURIComponent(query)}&filter=music_songs`);
            if (!res.ok) continue;
            const data = await res.json();
            if (data.items && data.items.length > 0) {
                // Find first valid video
                const video = data.items.find((i: any) => i.url && i.url.includes('/watch?v='));
                if (video) {
                    return video.url.split('v=')[1];
                }
            }
        } catch (e) {
            console.warn(`Piped instance ${instance} failed`, e);
            continue;
        }
    }
    return null;
};

const performSearch = async (query: string, key: string): Promise<string | null> => {
    try {
        const res = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=${encodeURIComponent(query)}&key=${key}`
        );
        
        // Handle Google 403/429 specifically
        if (res.status === 403 || res.status === 429) {
            throw new Error("API_QUOTA_LIMIT");
        }

        const data = await res.json();
        
        if (data.error) {
            console.warn(`API Key ${key.substring(0, 8)}... failed:`, data.error.message);
            throw new Error("API_FAIL"); 
        }

        if (data.items && data.items.length > 0) {
            return data.items[0].id.videoId;
        }
        return null; 
    } catch (e: any) {
        if (e.message === "API_FAIL" || e.message === "API_QUOTA_LIMIT") throw e;
        console.error("Network/Fetch error", e);
        throw new Error("NET_FAIL");
    }
};

export const getYoutubeId = async (query: string): Promise<string | null> => {
    // Attempt 1: Try exact query with official keys
    for (const key of YT_API_KEYS) {
        try {
            const videoId = await performSearch(query, key);
            if (videoId) return videoId;
        } catch (e: any) {
            // If quota limit, stop trying keys and switch to Piped immediately
            if (e.message === "API_QUOTA_LIMIT") break;
            continue; 
        }
    }

    // Attempt 2: Piped API Fallback (No Key, No Quota)
    try {
        console.log("Switching to Piped API fallback...");
        const videoId = await searchPiped(query);
        if (videoId) return videoId;
    } catch (e) {
        console.error("Piped fallback failed", e);
    }

    // Attempt 3: Fallback - Try simpler query with Piped
    const simpleQuery = query.replace(/official audio|official video|lyrics/gi, '').trim();
    if (simpleQuery !== query.trim()) {
        try {
             const videoId = await searchPiped(simpleQuery);
             if (videoId) return videoId;
        } catch (e) {
            console.error("Piped simple query failed", e);
        }
    }

    return null;
};

// Helper for JSONP requests (Bypasses CORS for iTunes Search API)
const fetchJsonp = (url: string, timeout = 5000): Promise<any> => {
    return new Promise((resolve, reject) => {
        const callbackName = 'jsonp_' + Math.round(100000 * Math.random());
        const script = document.createElement('script');
        
        const timer = setTimeout(() => {
            cleanup();
            reject(new Error('JSONP request timed out'));
        }, timeout);

        const cleanup = () => {
            if ((window as any)[callbackName]) delete (window as any)[callbackName];
            if (document.body.contains(script)) document.body.removeChild(script);
            clearTimeout(timer);
        };

        (window as any)[callbackName] = (data: any) => {
            cleanup();
            resolve(data);
        };

        script.onerror = () => {
            cleanup();
            reject(new Error('JSONP request failed'));
        };

        script.src = `${url}${url.includes('?') ? '&' : '?'}callback=${callbackName}`;
        document.body.appendChild(script);
    });
};

const fetchWithFallback = async (url: string) => {
    const strategies = [
        // Strategy 1: AllOrigins /get (Most reliable for RSS)
        async (u: string) => {
            const res = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(u)}`);
            if (!res.ok) throw new Error(`Proxy error: ${res.status}`);
            const data = await res.json();
            if (!data.contents) throw new Error('No contents in proxy response');
            return JSON.parse(data.contents);
        },
        // Strategy 2: CorsProxy.io
        async (u: string) => {
            const res = await fetch(`https://corsproxy.io/?${encodeURIComponent(u)}`);
            if (!res.ok) throw new Error(`Proxy error: ${res.status}`);
            return await res.json();
        },
        // Strategy 3: CodeTabs (Backup)
        async (u: string) => {
            const res = await fetch(`https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`);
            if (!res.ok) throw new Error(`Proxy error: ${res.status}`);
            return await res.json();
        }
    ];

    for (const strategy of strategies) {
        try {
            return await strategy(url);
        } catch (e) {
            console.warn(`Fetch strategy failed`, e);
            continue;
        }
    }
    
    throw new Error("All fetch strategies failed");
};

export const fetchSongs = async (term: string, limit: number = 25): Promise<Song[]> => {
    try {
        // Use JSONP for Search API - No proxies needed!
        const itunesUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(term)}&media=music&entity=song&limit=${limit}&country=in`;
        const data = await fetchJsonp(itunesUrl);
        
        if(!data.results) return [];

        return data.results.map((item: any) => ({
            title: item.trackName,
            artist: item.artistName,
            cover: item.artworkUrl100.replace('100x100bb', '600x600bb'),
            album: item.collectionName,
            ytId: null,
            searchQuery: `${item.trackName} ${item.artistName} official audio`
        }));
    } catch (e) {
        console.error("iTunes API Error (JSONP)", e);
        // Fallback to proxy if JSONP fails (rare)
        try {
             const itunesUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(term)}&media=music&entity=song&limit=${limit}&country=in`;
             const data = await fetchWithFallback(itunesUrl);
             if(!data.results) return [];
             return data.results.map((item: any) => ({
                title: item.trackName,
                artist: item.artistName,
                cover: item.artworkUrl100.replace('100x100bb', '600x600bb'),
                album: item.collectionName,
                ytId: null,
                searchQuery: `${item.trackName} ${item.artistName} official audio`
            }));
        } catch (proxyError) {
            console.error("iTunes API Error (Proxy Fallback)", proxyError);
            return [];
        }
    }
};

export const fetchTopCharts = async (): Promise<Song[]> => {
    try {
        const itunesUrl = 'https://itunes.apple.com/in/rss/topsongs/limit=20/json';
        const data = await fetchWithFallback(itunesUrl);

        if(!data.feed || !data.feed.entry) throw new Error("Invalid RSS data");
        
        const entries = data.feed.entry; 
        const shuffle = (array: any[]) => array.sort(() => Math.random() - 0.5);

        return shuffle(entries).map((item: any) => ({
            title: item['im:name'].label,
            artist: item['im:artist'].label,
            cover: item['im:image'][2].label.replace('170x170', '600x600'),
            searchQuery: `${item['im:name'].label} ${item['im:artist'].label} official audio`,
            ytId: null
        }));
    } catch (e) {
        console.error("Top Charts Error (RSS)", e);
        // Fallback to search API (JSONP) which is more reliable
        return await fetchSongs('top hits india', 20);
    }
};